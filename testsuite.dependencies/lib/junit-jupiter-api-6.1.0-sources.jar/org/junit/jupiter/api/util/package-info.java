/*
 * Copyright 2015-2026 the original author or authors.
 *
 * All rights reserved. This program and the accompanying materials are
 * made available under the terms of the Eclipse Public License v2.0 which
 * accompanies this distribution and is available at
 *
 * https://www.eclipse.org/legal/epl-v20.html
 */

/**
 * {@code java.util}-related support in JUnit Jupiter.
 *
 * @see org.junit.jupiter.api.util.DefaultLocale
 * @see org.junit.jupiter.api.util.DefaultTimeZone
 * @see org.junit.jupiter.api.util.SetSystemProperty
 */

@NullMarked
package org.junit.jupiter.api.util;

import org.jspecify.annotations.NullMarked;
