/**
 */
package Abc;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>A</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link Abc.A#getAtoB <em>Ato B</em>}</li>
 *   <li>{@link Abc.A#getAtoC <em>Ato C</em>}</li>
 * </ul>
 * </p>
 *
 * @see Abc.AbcPackage#getA()
 * @model
 * @generated
 */
public interface A extends EObject {
	/**
	 * Returns the value of the '<em><b>Ato B</b></em>' containment reference list.
	 * The list contents are of type {@link Abc.classB}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ato B</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ato B</em>' containment reference list.
	 * @see Abc.AbcPackage#getA_AtoB()
	 * @model containment="true"
	 * @generated
	 */
	EList<classB> getAtoB();

	/**
	 * Returns the value of the '<em><b>Ato C</b></em>' containment reference list.
	 * The list contents are of type {@link Abc.C}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ato C</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ato C</em>' containment reference list.
	 * @see Abc.AbcPackage#getA_AtoC()
	 * @model containment="true"
	 * @generated
	 */
	EList<C> getAtoC();
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // A
