/**
 */
package Abc;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>class B</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see Abc.AbcPackage#getclassB()
 * @model
 * @generated
 */
public interface classB extends EObject { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // classB
