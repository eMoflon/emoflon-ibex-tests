/**
 */
package Abc.impl;

import Abc.A;
import Abc.AbcPackage;
import Abc.C;
import Abc.classB;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>A</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link Abc.impl.AImpl#getAtoB <em>Ato B</em>}</li>
 *   <li>{@link Abc.impl.AImpl#getAtoC <em>Ato C</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class AImpl extends EObjectImpl implements A {
	/**
	 * The cached value of the '{@link #getAtoB() <em>Ato B</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAtoB()
	 * @generated
	 * @ordered
	 */
	protected EList<classB> atoB;

	/**
	 * The cached value of the '{@link #getAtoC() <em>Ato C</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAtoC()
	 * @generated
	 * @ordered
	 */
	protected EList<C> atoC;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AbcPackage.Literals.A;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<classB> getAtoB() {
		if (atoB == null) {
			atoB = new EObjectContainmentEList<classB>(classB.class, this, AbcPackage.A__ATO_B);
		}
		return atoB;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<C> getAtoC() {
		if (atoC == null) {
			atoC = new EObjectContainmentEList<C>(C.class, this, AbcPackage.A__ATO_C);
		}
		return atoC;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case AbcPackage.A__ATO_B:
			return ((InternalEList<?>) getAtoB()).basicRemove(otherEnd, msgs);
		case AbcPackage.A__ATO_C:
			return ((InternalEList<?>) getAtoC()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case AbcPackage.A__ATO_B:
			return getAtoB();
		case AbcPackage.A__ATO_C:
			return getAtoC();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case AbcPackage.A__ATO_B:
			getAtoB().clear();
			getAtoB().addAll((Collection<? extends classB>) newValue);
			return;
		case AbcPackage.A__ATO_C:
			getAtoC().clear();
			getAtoC().addAll((Collection<? extends C>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case AbcPackage.A__ATO_B:
			getAtoB().clear();
			return;
		case AbcPackage.A__ATO_C:
			getAtoC().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case AbcPackage.A__ATO_B:
			return atoB != null && !atoB.isEmpty();
		case AbcPackage.A__ATO_C:
			return atoC != null && !atoC.isEmpty();
		}
		return super.eIsSet(featureID);
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //AImpl
