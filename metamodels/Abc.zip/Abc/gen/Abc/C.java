/**
 */
package Abc;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>C</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link Abc.C#getCtoB <em>Cto B</em>}</li>
 * </ul>
 * </p>
 *
 * @see Abc.AbcPackage#getC()
 * @model
 * @generated
 */
public interface C extends EObject {
	/**
	 * Returns the value of the '<em><b>Cto B</b></em>' containment reference list.
	 * The list contents are of type {@link Abc.classB}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Cto B</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cto B</em>' containment reference list.
	 * @see Abc.AbcPackage#getC_CtoB()
	 * @model containment="true"
	 * @generated
	 */
	EList<classB> getCtoB();
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // C
